README

FOR RESEARCH USE ONLY.

The SARCOV2_Swift_Illumina-2.0.cpw workflow has been contributed by Gonzalo Manrique <grmanrique@fcien.edu.uy>.

It is compatible with CLC Genomics Workbench v20 or newer, and is provided as is without warrenty. 

Please contact QIAGEN Digital Insights for support questions related to CLC Genomics Workbench. For questions related to this workflow specifically, please contact Gonzalo Manrique <grmanrique@fcien.edu.uy>.